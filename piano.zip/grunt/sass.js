module.exports = {
    dev: {
        options: {
            outputStyle: 'expanded',
            sourceMap:true
        },
        files: {
            'public/css/app.css': 'src/scss/index.scss'
        }
    }
};
