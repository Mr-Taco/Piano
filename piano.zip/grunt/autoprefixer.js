module.exports = {
    dist:{
        options: {
            browsers:['last 2 versions'],
            map:true
        },
        files: {
            'public/css/app.css': 'public/css/app.css'
        }
    }
};
